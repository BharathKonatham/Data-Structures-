Name Balanarahariraju Bollepalli
Email bollepalli.4@wright.edu


[loki]>ls -l
total 951
-rw-r--r-- 1 w358bxb csgrad    830 Oct  4 20:03 answers.txt
-rw------- 1 w358bxb csgrad   2902 Apr  2  2007 bitvector.cpp
-rw-r--r-- 1 w358bxb csgrad  18096 Oct  3 12:44 bitvector.o
-rw-r--r-- 1 w358bxb csgrad   6525 Oct  3 12:39 cmdsTried.txt
-rw------- 1 w358bxb csgrad  65536 Oct  3 12:55 D1.dsk
-rw------- 1 w358bxb csgrad 262144 Oct  3 14:39 D2.dsk
-rw------- 1 w358bxb csgrad   5352 Oct 30  2020 directory.cpp
-rw-r--r-- 1 w358bxb csgrad  24888 Oct  3 12:44 directory.o
-rw------- 1 w358bxb csgrad    174 Apr  2  2007 diskParams.dat
-rw------- 1 w358bxb csgrad   4199 Apr  2  2007 file.cpp
-rw-r--r-- 1 w358bxb csgrad  21088 Oct  3 12:44 file.o
-rw------- 1 w358bxb csgrad   7000 Apr  2  2007 fs33types.hpp
-rw-r--r-- 1 w358bxb csgrad   4891 Oct  3 13:01 gdbSession.txt
-rw------- 1 w358bxb csgrad   7569 Apr  2  2007 inodes.cpp
-rw-r--r-- 1 w358bxb csgrad  26920 Oct  3 12:44 inodes.o
-rw------- 1 w358bxb csgrad    722 Jul  7  2020 Makefile
-rw------- 1 w358bxb csgrad   3641 Apr  2  2007 mount.cpp
-rw-r--r-- 1 w358bxb csgrad  25736 Oct  3 12:44 mount.o
-rwxr-xr-x 1 w358bxb csgrad 111400 Oct  3 14:39 P0
-rw-r--r-- 1 w358bxb csgrad   2301 Oct  4 19:04 ReadMe.txt
-rw------- 1 w358bxb csgrad  10313 Oct  3 14:39 shell.cpp
-rw------- 1 w358bxb csgrad   9044 Oct 29  2020 shell.cpp~
-rw-r--r-- 1 w358bxb csgrad  57088 Oct  3 14:39 shell.o
-rw------- 1 w358bxb csgrad   3780 Apr  2  2007 simdisk.cpp
-rw-r--r-- 1 w358bxb csgrad  23488 Oct  3 12:44 simdisk.o
-rwxr-xr-x 1 w358bxb csgrad    216 Oct  3 14:24 test
-rw-r--r-- 1 w358bxb csgrad     69 Oct  4 18:33 testscript.txt
-rw-r--r-- 1 w358bxb csgrad   2718 Sep 24  2020 typescript
-rw------- 1 w358bxb csgrad    112 Apr  2  2007 user.cpp
-rw------- 1 w358bxb csgrad   6808 Apr  2  2007 volume.cpp
-rw-r--r-- 1 w358bxb csgrad  27832 Oct  3 12:44 volume.o



Documentation: Initially i thought it is a  bit challenge to accomplish the tasks but once i started run commands,i got to know the usage of some commands and how to keep the break points in the infinite loop then debugging the command line using GDB and also ihave learned the redirect the output of a command into a file on the host's file system. Gained the knowledge about Piping by giving output of one process as input of the another process. 
