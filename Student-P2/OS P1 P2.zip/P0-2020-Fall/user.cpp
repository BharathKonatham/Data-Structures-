/*
 * mount.C of CEG433/633 File Sys Project 
 * pmateti@wright.edu   */

#include "fs33types.hpp"

/* -eof- */
